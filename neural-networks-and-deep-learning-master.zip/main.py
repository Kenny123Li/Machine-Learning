import nmist_loader
import network

net = network.Network([784, 30, 10])
net.SGD(training_data, 30, 10, 2.0, test_data=test_data)